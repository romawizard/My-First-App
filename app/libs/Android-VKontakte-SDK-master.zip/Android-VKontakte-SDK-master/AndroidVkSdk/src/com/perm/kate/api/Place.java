package com.perm.kate.api;

public class Place {
    public String place_id;
    public String title;
    public String type;
    public String country_id;
    public String city_id;
    public String address;
}
