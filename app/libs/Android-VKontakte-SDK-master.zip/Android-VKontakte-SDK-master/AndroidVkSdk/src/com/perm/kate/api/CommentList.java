package com.perm.kate.api;

import java.util.ArrayList;

public class CommentList {
    public int count;
    public ArrayList<Comment> comments=new ArrayList<Comment>();

}
